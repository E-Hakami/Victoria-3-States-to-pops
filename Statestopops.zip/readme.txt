#Discreption 

This tool takes the State ownership 3 letters ID from 00_states.txt and use it to replace the ones from Pops and buildings

it will just replace the IDs so its not perfectt but good for game tetsing purposes, make sure to update thecnologies in the countries file  

###How to use

- in the gamefiles/states Folder put your custom 00_states.txt file 
- run the excutable
- it will replace all 3 letteres IDs
- you can find the new files in the output folder